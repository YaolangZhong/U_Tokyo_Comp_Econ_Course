# Lab materials

Open the starter folder for the notebook, script, and setup instructions. Slide PDFs are in slides/pdf/.

Homework and current course materials: https://yaolangzhong.github.io/U_Tokyo_Comp_Econ_Course/weeks/week_02/index.html
